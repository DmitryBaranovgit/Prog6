import sys
sys.path.append('server')

import grpc
import glossary_pb2
import glossary_pb2_grpc

def run():
    channel = grpc.insecure_channel('localhost:50051')
    stub = glossary_pb2_grpc.GlossaryServiceStub(channel)

    term = glossary_pb2.Term(
        name="Example",
        definition="This is an example term.",
        related_terms=[],
        source="test"
    )
    resp_add = stub.AddTerm(term)
    print("AddTerm response:", resp_add)

    response = stub.ListTerms(glossary_pb2.Empty())
    print("ListTerms response:", [t.name for t in response.terms])

if __name__ == '__main__':
    run()