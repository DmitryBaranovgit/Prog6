import grpc
from concurrent import futures
import glossary_pb2
import glossary_pb2_grpc
import json
import os

DATA_FILE = "data/terms.json"
terms_db = {}

def load_terms():
    if os.path.exists(DATA_FILE):
        with open(DATA_FILE, "r", encoding="utf-8") as f:
            try:
                data = json.load(f)
                for term in data:
                    terms_db[term["name"]] = term
                print(f"[INFO] loaded {len(terms_db)} terms from {DATA_FILE}")
            except json.JSONDecodeError:
                print("[WARN] Failed to decode JSON. Starting with empty DB.")

def save_terms():
    os.makedirs(os.path.dirname(DATA_FILE), exist_ok=True)
    with open(DATA_FILE, "w", encoding="utf-8") as f:
        json.dump(list(terms_db.values()), f, ensure_ascii=False, indent=2)
    print("[INFO] Terms saved.")

class GlossaryServiceServicer(glossary_pb2_grpc.GlossaryServiceServicer):
    def ListTerms(self, request, context):
        return glossary_pb2.TermList(
            terms=[glossary_pb2.Term(**term) for term in terms_db.values()]
        )
    
    def GetTerm(self, request, context):
        term = terms_db.get(request.name)
        if term:
            return glossary_pb2.Term(**term)
        context.set_code(grpc.StatusCode.NOT_FOUND)
        context.set_details('Term not found')
        return glossary_pb2.Term()
    
    def AddTerm(self, request, context):
        if request.name in terms_db:
            return glossary_pb2.Response(success=False, message="Already exists")
        terms_db[request.name] = {
            "name": request.name,
            "definition": request.definition,
            "related_terms": list(request.related_terms),
            "source": request.source
        }
        save_terms()
        return glossary_pb2.Response(success=True, message="Added")
    
    def UpdateTerm(self, request, context):
        if request.name not in terms_db:
            return glossary_pb2.Response(success=False, message="Not Found")
        terms_db[request.name] = {
            "name": request.name,
            "definition": request.definition,
            "related_terms": list(request.related_terms),
            "source": request.source
        }
        save_terms()
        return glossary_pb2.Response(success=True, message="Updated")
    
    def DeleteTerm(self, request, context):
        if request.name in terms_db:
            del terms_db[request.name]
            save_terms()
            return glossary_pb2.Response(success=True, message="Deleted")
        return glossary_pb2.Response(success=False, message="Not found")
    
def serve():
    load_terms()
    server = grpc.server(futures.ThreadPoolExecutor(max_workers=10))
    glossary_pb2_grpc.add_GlossaryServiceServicer_to_server(GlossaryServiceServicer(), server)
    server.add_insecure_port('[::]:50051')
    server.start()
    print("PC Glossary Server started on port 50051.")
    server.wait_for_termination()

if __name__ == '__main__':
    serve()