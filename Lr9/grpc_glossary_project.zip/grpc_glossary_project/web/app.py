from flask import Flask, render_template, jsonify, request
import grpc
import glossary_pb2
import glossary_pb2_grpc

app = Flask(__name__)

def fetch_terms():
    channel = grpc.insecure_channel('server:50051')
    stub = glossary_pb2_grpc.GlossaryServiceStub(channel)
    response = stub.ListTerms(glossary_pb2.Empty())
    return response.terms

@app.route("/")
def index():
    terms = fetch_terms()

    node_ids = set(term.name for term in terms)
    nodes = [{"id": term.name, "group": 1} for term in terms]
    links = []

    for term in terms:
        for rel in term.related_terms:
            links.append({"source": term.name, "target":rel, "value": 1})
            if rel not in node_ids:
                nodes.append({"id": rel, "group": 2})
                node_ids.add(rel)
    graph_data = {
        "nodes": nodes,
        "links": links
    }
    
    return render_template("graph.html", graph_data=graph_data)

@app.route("/api/terms", methods=["GET"])
def api_terms():
    terms = fetch_terms()
    return jsonify([{
        "name": t.name,
        "definition": t.definition,
        "related_terms": list(t.related_terms),
        "source": t.source
    } for t in terms])

@app.route("/api/terms", methods=["POST"])
def api_add_term():
    data = request.get_json()
    name = data.get("name")
    definition = data.get("definition", "")
    related = data.get("related_terms", [])
    source = data.get("source", "")
    if not name:
        return jsonify({"success": False, "message": "Field 'name' is required"}), 400
    
    channel = grpc.insecure_channel('server:50051')
    stub = glossary_pb2_grpc.GlossaryServiceStub(channel)
    term = glossary_pb2.Term(
        name = name,
        definition=definition,
        related_terms=related,
        source=source
    )
    resp = stub.AddTerm(term)
    status_code = 200 if resp.success else 409
    return jsonify({"success": resp.success, "message": resp.message}), status_code

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8080)